(function ($) {
	// console.log('loaded');
	jQuery(document).ready(function($) {
			jQuery('#cname').select2();
			jQuery('#ptype').select2();

	});
})(jQuery);