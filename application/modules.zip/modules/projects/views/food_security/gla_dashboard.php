<section class="panel panel-featured panel-featured-success">
   
    <div class="panel-body">

    	<div class="row">

    		<div class="col-md-4">
    			<section class="panel">
					<header class="panel-heading bg-info">
						<h5 class="text-weight-semibold mt-sm text-center"><strong>SOIL & WATER CONSERVATION</strong></h5>
					</header>
					<div class="panel-body text-center">
						<p>Target Areas</p>
					
					</div>
					<div class="panel-footer panel-footer-btn-group text-center" >
						<a href="<?php echo site_url();?>soil-conservation/<?php echo $data_page_id?>" ><i class="fa fa-folder-open mr-xs"></i> OPEN DATA</a>
					</div>
				</section>
    		</div>
    		<div class="col-md-4">
    			<section class="panel">
					<header class="panel-heading bg-info">
						<h5 class="text-weight-semibold mt-sm text-center"><strong>FOOD SECURITY INITIATIVE</strong></h5>
					</header>
					<div class="panel-body text-center">
						<p>Target Areas</p>
					
					</div>
					<div class="panel-footer panel-footer-btn-group text-center" >
						<a href="<?php echo site_url();?>food-security/<?php echo $data_page_id?>" ><i class="fa fa-folder-open mr-xs"></i> OPEN DATA</a>
					</div>
				</section>
    		</div>
    		<div class="col-md-4">
    			<section class="panel">
					<header class="panel-heading bg-info">
						<h5 class="text-weight-semibold mt-sm text-center"><strong>TRAINER OF TRAINEES</strong></h5>
					</header>
					<div class="panel-body text-center">
						<p>Target Areas</p>
					
					</div>
					<div class="panel-footer panel-footer-btn-group text-center" >
						<a href="<?php echo site_url();?>trainer-of-trainees/<?php echo $data_page_id?>" ><i class="fa fa-folder-open mr-xs"></i> OPEN DATA</a>
					</div>
				</section>
    		</div>
    		</div>
    	</div>
    </section>