<?php
if($branch_data->num_rows()>0)
{
	$branch_details = $branch_data->result();
	foreach($branch_details as $rows)
	{
		$branch_name = $rows->branch_name;
		$branch_address = $rows->branch_address;
		$branch_post_code = $rows->branch_post_code;
		$branch_city = $rows->branch_city;
		$branch_email = $rows->branch_email;
		$branch_phone = $rows->branch_phone;
		$branch_location = $rows->branch_location;
		$branch_image_name = $rows->branch_image_name;
	}
}


$count = 0;
$result = 
	'<table class="table table-bordered table-striped table-condensed">
		<thead>
			<tr>
				<th colspan="6"></th>
				<th colspan="3">RIPARIAN</th>
				<th colspan="3">AGROFORESTRY TREES</th>
				<th colspan="4">SOIL CONSERVATION</th>
				<th colspan="1">COFFEE</th>
				<th colspan="3">GRASS</th>
				<th colspan="4">COVER CROPS	</th>		
			</tr>
			<tr>
				<th>#</th>
				<th>Farmer Name</th>
				<th>Phone</th>
				<th>GPS CODE</th>

				<th>Eastings</th>
				<th>Northings</th>

				<th>Type</th>
				<th>Dist</th>
				<th>Qnty</th>

				<th>Type</th>
				<th>Spacing</th>
				<th>Qnty</th>

				<th>Type</th>
				<th>Spacing</th>
				<th>Qnty</th>
				<th>Rows</th>


				<th>Qnty</th>

				<th>Qnty</th>
				<th>Rows</th>
				<th>Spacing</th>

				<th>Type</th>
				<th>Qnty</th>
				<th>Rows</th>
				<th>Spacing</th>
			</tr>
				';
				if($food_security_query->num_rows()>0)
				{
					$row = $food_security_query->result();
					foreach($row as $key)
					{

						$name = $key->name;
						$phone = $key->phone;
						$gps = $key->gps;
						$eastings = $key->eastings;
						$northings = $key->northings;

						$ag_type = $key->ag_type;
						$ag_spacing = $key->ag_spacing;
						$ag_quantity = $key->ag_quantity;

						$sc_type = $key->sc_type;
						$sc_bench = $key->sc_bench;
						$sc_quantity = $key->sc_quantity;

						$r_type = $key->r_type;
						$r_dist = $key->r_dist;
						$r_quantity = $key->r_quantity;

						$c_row = $key->c_row;
						$c_quantity = $key->c_quantity;
						$g_quantity = $key->g_quantity;

						$g_rows = $key->g_rows;
						$g_spacing = $key->g_spacing;
						$cc_type = $key->cc_type;

						$cc_quantity = $key->cc_quantity;
						$cc_rows = $key->cc_rows;
						$cc_spacing = $key->cc_spacing;


						$count++;
						$result .=
								'<tr>
									<td>'.$count.'</td>
									<td>'.$name.'</td>
									<td>'.$phone.'</td>
									<td>'.$gps.'</td>

									<td>'.$eastings.'</td>
									<td>'.$northings.'</td>

									<td>'.$ag_type.'</td>
									<td>'.$ag_spacing.'</td>
									<td>'.$ag_quantity.'</td>

									<td>'.$sc_type.'</td>
									<td>'.$sc_bench.'</td>
									<td>'.$sc_quantity.'</td>

									<td>'.$r_type.'</td>
									<td>'.$r_dist.'</td>
									<td>'.$r_quantity.'</td>
									<td>'.$c_row.'</td>
									<td>'.$c_quantity.'</td>

									<td>'.$g_quantity.'</td>
									<td>'.$g_rows.'</td>
									<td>'.$g_spacing.'</td>

									<td>'.$cc_type.'</td>
									<td>'.$cc_quantity.'</td>
									<td>'.$cc_rows.'</td>
									<td>'.$cc_spacing.'</td>
								</tr>
								';
					}
					
					
				}
$result .= 
	'
	</table>
	';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Attendees</title>
        <!-- For mobile content -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- IE Support -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url()."assets/themes/porto-admin/1.4.1/";?>assets/vendor/bootstrap/css/bootstrap.css" />
        <link rel="stylesheet" href="<?php echo base_url()."assets/themes/porto-admin/1.4.1/";?>assets/stylesheets/theme-custom.css">
		<style type="text/css">
            .receipt_spacing{letter-spacing:0px; font-size: 12px;}
            .center-align{margin:0 auto; text-align:center;}
            
            .receipt_bottom_border{border-bottom: #888888 medium solid; margin-bottom:20px;}
            .row .col-md-12 table {
                border:solid #000 !important;
                border-width:1px 0 0 1px !important;
                font-size:10px;
            }
            .row .col-md-12 th, .row .col-md-12 td {
                border:solid #000 !important;
                border-width:0 1px 1px 0 !important;
            }
            
            .row .col-md-12 .title-item{float:left;width: 130px; font-weight:bold; text-align:right; padding-right: 20px;}
            .title-img{float:left; padding-left:30px;}
            img.logo{max-height:70px; margin:0 auto;}
            .align-right{text-align: right !important;}
            .align-left{text-align: left !important;}
            .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td{border-top:none;}
			td.bottom-border{border-bottom:1px solid #d8d8d8; width:70%;}
        </style>
    </head>
    <body class="receipt_spacing" onLoad="window.print();return false;">
    	<div class="col-md-12 center-align receipt_bottom_border">
    		<table class="table table-condensed">
                <tr>
                    <th>GBM SOIL AND WATER CONSERVATION INITIATIVES FORM</th>
                    <th class="align-right">
						<?php echo $branch_name;?><br/>
                        <?php echo $branch_address;?> <?php echo $branch_post_code;?> <?php echo $branch_city;?><br/>
                        E-mail: <?php echo $branch_email;?><br/>
                        Tel : <?php echo $branch_phone;?><br/>
                        <?php echo $branch_location;?>
                    </th>
                    <th>
                        <img src="<?php echo base_url().'assets/logo/'.$branch_image_name;?>" alt="<?php echo $branch_name;?>" class="img-responsive logo"/>
                    </th>
                </tr>
            </table>
        </div>
        
    	<div class="col-md-12 receipt_bottom_border">
    		<table class="table table-condensed">
                <tr>
                    <td class="center-align">
                        <strong>Constituency Name: </strong> Kibera Constituency
                        <strong>Ward: </strong> Upper Kibera
                        <strong>Catchment: </strong> Kibera River
                    </td>
                </tr>
        	</table>
        </div>
       	<div class="col-md-12 receipt_bottom_border">
			<?php echo $result;?>
        </div>
        
        <table class="table table-condensed">
        	<tr>
        		<td>
		        	<table class="table table-condensed">
		            	<tr>
		                	<th class="align-right">MAPPED BY</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            	<tr>
		                	<th class="align-right">DATE</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            	<tr>
		                	<th class="align-right">SIGNATURE</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            </table>
		        </td>
		        <td>
		        	<table class="table table-condensed">
		            	<tr>
		                	<th class="align-right">RECEIVED BY</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            	<tr>
		                	<th class="align-right">DATE</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            	<tr>
		                	<th class="align-right">SIGNATURE</th>
		                    <td class="bottom-border"></td>
		                </tr>
		            </table>
		         </td>
		        </tr>
        </table>
    </body>
</html>