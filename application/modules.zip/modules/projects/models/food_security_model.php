<?php

class Food_security_model extends CI_Model 
{
	
}
?>